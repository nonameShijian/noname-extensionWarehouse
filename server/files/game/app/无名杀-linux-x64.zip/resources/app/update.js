window.updateList = [
	//app文件夹
	'app/index.js',
	'app/menu.js',
	'app/redirect.js',
	
	'downloadExtension.html',
	'main.js',
	'package.json',
	'package-lock.json',
	'update.html',
];
